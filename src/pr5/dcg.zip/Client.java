package pr5;

public class Client extends Person{
    public Client(Integer idPersona, String dni, String name, String surname, Address fullAddress) {
        super(idPersona, dni, name, surname, fullAddress);
    }
}
