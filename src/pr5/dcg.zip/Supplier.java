package pr5;

public class Supplier extends Person{
    public Supplier(Integer idPersona, String dni, String name, String surname, Address fullAddress) {
        super(idPersona, dni, name, surname, fullAddress);
    }
}
