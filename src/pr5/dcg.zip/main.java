package pr5;

public class main {
    public static void main(String[] args) {
        View v = new View();
        v.run();
    }
}
