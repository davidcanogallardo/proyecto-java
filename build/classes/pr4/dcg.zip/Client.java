package pr4;

public class Client extends Person{
    public Client(int idPersona, String dni, String name, String surname, Address fullAddress) {
        super(idPersona, dni, name, surname, fullAddress);
    }
}
