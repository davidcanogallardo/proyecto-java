package pr4;

import java.util.HashMap;

public class GestorClient implements Persistable {
    private HashMap<Integer, Client> clientHashMap = new HashMap<Integer, Client>();
    
    //Interfaces
    @Override
    public Object add(Object obj) {
        if (obj != null) {
            if (obj instanceof Client) {
                Client client = (Client)obj;
                if (clientHashMap.containsKey(client.getIdPersona())) {
                    return null;
                } else {
                    clientHashMap.put(client.getIdPersona(), client);
                    return obj;
                } 
            }
        }
        
        return null;
    }
    
    @Override
    public Object delete(int id) {
        if (clientHashMap.containsKey(id)) {
            Client c = clientHashMap.get(id);
            clientHashMap.remove(id);
            return c;
        } else {
            return null;
        }
    }
    
    @Override
    public Object get(int id) {
        if (clientHashMap.containsKey(id)) {
            return clientHashMap.get(id);
        } else {
            return null;
        }
    }
    
    @Override
    public HashMap<Integer, Object> getMap() {
        HashMap<Integer, Object> a = new HashMap<Integer, Object>(clientHashMap);
        return a;
    }
    
    public void modifyClient(int idPersona, String dni, String name, String surname, Address address) {
        Client client = (Client) get(idPersona);
        //Guardo la dirección del cliente
        Address addClient = client.getFullAddress();
        //Solo cambia el atributo si su valor no es " "
        if (!" ".equals(dni)) {
            client.setDni(dni);
        } 
        
        if(!" ".equals(name)) {
            client.setName(name);
        }
        
        if(!" ".equals(surname)) {
            client.setSurname(surname);
        }
        
        //Para cambiar los datos de la dirección utilizo 
        //la variable que he obtenido antes
        if (!" ".equals(address.getLocality())) {
            addClient.setLocality(address.getLocality());
        }
        
        if (!" ".equals(address.getProvince())) {
            addClient.setProvince(address.getProvince());
        }
        
        if (!" ".equals(address.getZipCode())) {
            addClient.setZipCode(address.getZipCode());
        }
        
        if (!" ".equals(address.getAddress())) {
            addClient.setAddress(address.getAddress());
        }
        //Finalmente cambio la dirección por la dirección modificada
        client.setFullAddress(addClient);
    }
    
    public boolean clientExists(int id) {
        return clientHashMap.containsKey(id);
    }

 }

