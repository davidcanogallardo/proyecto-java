package pr4;

import java.util.ArrayList;
import java.util.HashMap;

public class GestorSupplier implements Persistable{
    private static HashMap<Integer, Supplier> supplierHashMap = new HashMap<Integer, Supplier>();
    
    //Interfaces
    @Override
    public Object add(Object obj) {
        if (obj != null) {
            if (obj instanceof Supplier) {
                Supplier s = (Supplier)obj;
                if (supplierHashMap.containsKey(s.getIdPersona())) {
                    return null;
                } else {
                    supplierHashMap.put(s.getIdPersona(), s);
                    return obj;
                } 
            }
        }
        
        return null;
    }
    
    @Override
    public Object delete(int id) {
        if (supplierHashMap.containsKey(id)) {
            Supplier s = supplierHashMap.get(id);
            supplierHashMap.remove(id);
            return s;
        } else {
            return null;
        }
    }
    
    @Override
    public Object get(int id) {
        if (supplierHashMap.containsKey(id)) {
            return supplierHashMap.get(id);
        } else {
            return null;
        }
    }
    
    @Override
    public HashMap<Integer, Object> getMap() {
        HashMap<Integer, Object> hm = new HashMap<>(supplierHashMap);
        return hm;
    }
    
    
    public void modifySupplier(int idPersona, String dni, String name, String surname, Address address) {
        Supplier supplier = (Supplier) get(idPersona);
        //Guardo la dirección del cliente
        Address addSupplier = supplier.getFullAddress();
        
        //Solo cambia el atributo si su valor no es " "
        if (!" ".equals(dni)) {
            supplier.setDni(dni);
        } 
        
        if(!" ".equals(name)) {
            supplier.setName(name);
        }
        
        if(!" ".equals(surname)) {
            supplier.setSurname(surname);
        }
        
        //Para cambiar los datos de la dirección utilizo 
        //la variable que he obtenido antes
        if (!" ".equals(address.getLocality())) {
            addSupplier.setLocality(address.getLocality());
        }
        
        if (!" ".equals(address.getProvince())) {
            addSupplier.setProvince(address.getProvince());
        }
        
        if (!" ".equals(address.getZipCode())) {
            addSupplier.setZipCode(address.getZipCode());
        }
        
        if (!" ".equals(address.getAddress())) {
            addSupplier.setAddress(address.getAddress());
        }
        //Finalmente cambio la dirección por la dirección modificada
        supplier.setFullAddress(addSupplier);
    }
    
    public boolean supplierExists(int id) {
        return supplierHashMap.containsKey(id);
    }
 }

