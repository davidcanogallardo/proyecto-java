package pr4;

import java.util.HashMap;

public interface Persistable {
    public abstract Object add(Object obj);
    public abstract Object delete(int id);
    public abstract Object get(int id);
    public abstract HashMap<Integer, Object> getMap();
}
